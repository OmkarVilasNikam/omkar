import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule , routingComponents} from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductEntryComponent } from './product-entry/product-entry.component';
import { ViewOrderComponent } from './view-order/view-order.component';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { ProfileComponent } from './profile/profile.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { HomeLoginComponent } from './homelogin/homelogin.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatCardModule} from '@angular/material/card';
import {MatGridListModule} from '@angular/material/grid-list';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import { HttpClientModule, HttpHeaders } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';
import { LogoutComponent } from './logout/logout.component';
import { DeleteComponent } from './delete/delete.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ProductaddComponent } from './productadd/productadd.component';
import { AboutComponent } from './about/about.component';
import { OmkarComponent } from './omkar/omkar.component';


@NgModule({
  declarations: [
    AppComponent,
    ProductEntryComponent,
    ViewOrderComponent,
    ViewDetailsComponent,
    UserProfileComponent,
    ProfileComponent,
    FooterComponent,
    HeaderComponent,
    HomeLoginComponent,
    routingComponents,
    LogoutComponent,
    DeleteComponent,
    AboutComponent,
    AdminloginComponent,

    ProductaddComponent,
     OmkarComponent
        ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    MatFormFieldModule,
    MatCardModule,
    MatGridListModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,HttpClientModule,MatIconModule,
    BrowserAnimationsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent,routingComponents]
})
export class AppModule { }




