import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homelogin',
  templateUrl: './homelogin.component.html',
  styleUrls: ['./homelogin.component.css']
})
export class HomeLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
