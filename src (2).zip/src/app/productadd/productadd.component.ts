import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productadd',
  templateUrl: './productadd.component.html',
  styleUrls: ['./productadd.component.css']
})
export class ProductaddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
