export class medical{
    name:string="";
    id:number=0;
    tabletname:string="";
    
    constructor(name: any,id: number,tabletname: string){
       
        this.name=name;
        this.id=id;
        this.tabletname=tabletname;
        
    }
}