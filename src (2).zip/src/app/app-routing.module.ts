import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DepartmentComponent } from './department/department.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { DetailsComponent } from './details/details.component';
import { ProductEntryComponent } from './product-entry/product-entry.component';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { ViewOrderComponent } from './view-order/view-order.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { PaymentFormComponent } from './payment-form/payment-form.component';
import { PaymentConfirmationComponent } from "./payment-confirmation/payment-confirmation.component";
import { LogoutComponent } from './logout/logout.component';
import { DeleteComponent } from './delete/delete.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ProductaddComponent } from './productadd/productadd.component';
import { AboutComponent } from './about/about.component';

const routes: Routes =[
  {path: '', component: DepartmentComponent},
  {path: 'employees', component: EmployeeListComponent},
  { path: 'payment-form', component: PaymentFormComponent },
  { path: 'payment-confirmation/:amount', component: PaymentConfirmationComponent},
  {path: 'register', component: RegisterComponent},
  {path: 'login', component: LoginComponent},
  {path: 'view-details', component: ViewDetailsComponent},
  {path: 'logout', component: LogoutComponent},
  {path:'delete', component: DeleteComponent},
  {path: 'adminlogin', component:AdminloginComponent},
  {path: 'product-entry', component:ProductEntryComponent},
  {path: 'view-order', component:ViewOrderComponent},
  {path: 'user-profile', component:UserProfileComponent},
  {path: 'productadd', component:ProductaddComponent},
  {path: 'about', component:AboutComponent},
  {
    path:'details',
    component:DetailsComponent
  },
  {
    path:'addtocart',
    component:AddToCartComponent
  }
   ];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[EmployeeListComponent,DepartmentComponent,PaymentFormComponent,PaymentConfirmationComponent,RegisterComponent,LoginComponent,DetailsComponent,AddToCartComponent,ViewDetailsComponent,LogoutComponent,DeleteComponent,AdminloginComponent,ProductEntryComponent,ViewOrderComponent,UserProfileComponent,ProductaddComponent,AboutComponent] 



