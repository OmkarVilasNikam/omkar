import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-omkar',
  templateUrl: './omkar.component.html',
  styleUrls: ['./omkar.component.css']
})
export class OmkarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
