import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule , routingComponents} from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductEntryComponent } from './product-entry/product-entry.component';
import { ViewOrderComponent } from './view-order/view-order.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { RegisterComponent } from './register/register.component';
import { ProfileComponent } from './profile/profile.component';
import { DetailsComponent } from './details/details.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { HomeLoginComponent } from './homelogin/homelogin.component';
import { PaymentConfirmationComponent } from './payment-confirmation/payment-confirmation.component';
import { PaymentFormComponent } from './payment-form/payment-form.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
@NgModule({
  declarations: [
    AppComponent,
    ProductEntryComponent,
    ViewOrderComponent,
    ViewDetailsComponent,
    LoginComponent,
    UserProfileComponent,
    RegisterComponent,
    DetailsComponent,
    ProfileComponent,
    AddToCartComponent,
    FooterComponent,
    HeaderComponent,
    HomeLoginComponent,
    PaymentFormComponent,
    PaymentConfirmationComponent,
    routingComponents
        ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
