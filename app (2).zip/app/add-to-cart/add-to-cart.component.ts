import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnInit {

  products=[
    {
      "name":"Azithral",
      "price":"119"
    },
    {
      "name":"augmentin 625",
      "price":"225.25"
    }, {
      "name":"ascoril syrup",
      "price":"108"
    }]

    getNavigation()
    {

    }
  constructor() { }

  ngOnInit(): void {
  }

}
