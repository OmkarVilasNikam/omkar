import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DepartmentComponent } from './department/department.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { DetailsComponent } from './details/details.component';
import { ProductEntryComponent } from './product-entry/product-entry.component';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { ViewOrderComponent } from './view-order/view-order.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { PaymentFormComponent } from './payment-form/payment-form.component';
import { PaymentConfirmationComponent } from "./payment-confirmation/payment-confirmation.component";

const routes: Routes =[
  {path: 'department', component: DepartmentComponent},
  {path: 'employees', component: EmployeeListComponent},
  { path: 'payment-form', component: PaymentFormComponent },
  { path: 'payment-confirmation/:amount', component: PaymentConfirmationComponent},
  {path: 'register', component: RegisterComponent},
  {path: 'login', component: LoginComponent},
  
  {
    path:'details',
    component:DetailsComponent
  },
  {
    path:'addtocart',
    component:AddToCartComponent
  }
   ];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[EmployeeListComponent,DepartmentComponent]