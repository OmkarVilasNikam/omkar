import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  products=[
    {
      "name":"Azithral",
      "companyname":"Almebic pharma ltd",
      "description":"Azithromycin",
      "mdate":"12-dec-2020",
      "exdate":"25-dec-2022",
      "price":"119"
    },
    {
      "name":"Augmentin 625",
      "companyname":"clipa pvt ltd",
      "description":"amoxyciliin(500mg)+clavulanic acid(125mg)",
      "mdate":"12-dec-2021",
      "exdate":"25-dec-2023",
      "price":"225"
    },
    {
      "name":"Ascoril ls syrup",
      "companyname":"gelmark pharma ltd",
      "description":"Ambroxal(30mg/5ml)+levasalbutamol(1mg/5ml)+Guainesin(50mg/5ml)",
      "mdate":"12-dec-2020",
      "exdate":"25-dec-2022",
      "price":"654"
    },
    {
      "name":" Alex syrup",
      "companyname":"gelmark pharma ltd",
      "description":"Ambroxal(2mg/5ml)+levasalbutamol(11mg/5ml)+Guainesin(50mg/5ml)",
      "mdate":"12-dec-2020",
      "exdate":"25-dec-2022",
      "price":"500"
    },
    {
      "name":"Azee tablet",
      "companyname":"clipa ltd",
      "description":"Azithromicin(500mg)",
      "mdate":"12-dec-2020",
      "exdate":"25-dec-2022",
      "price":"235"
    }
   
  ]


  constructor() { }

  ngOnInit(): void {
  }

}
